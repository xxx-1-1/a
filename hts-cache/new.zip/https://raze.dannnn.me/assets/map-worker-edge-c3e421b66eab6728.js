import "https://download.dannnn.me/native/c3e421b66eab6728/program/assets/map-brotli-worker-DJS_4OOQ.js?raze-channel=public-cors-v1";
